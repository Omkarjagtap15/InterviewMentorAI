import HomeContent from "@/components/shared/HomeContent";


export default function Home() {
  return (
    <div>
     <HomeContent/>
    </div>
  );
}
